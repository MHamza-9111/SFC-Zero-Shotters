#!/usr/bin/env python3
"""Build DineIQ Intelligence Suite: concat parts -> single self-contained HTML."""
import pathlib, re, sys

SRC = pathlib.Path(__file__).parent
OUT = SRC.parent / "dineiq-intelligence-suite.html"

PARTS_HTML_HEAD = ["01_head.html", "02_shell.html"]
PARTS_JS = [
    "03_data.js", "04_charts.js", "05_views_core.js", "06_views_ops.js",
    "07_views_risk.js", "08_views_models.js", "09_views_admin.js", "10_app.js",
]

def main():
    chunks = []
    for p in PARTS_HTML_HEAD:
        chunks.append((SRC / p).read_text())
    for p in PARTS_JS:
        body = (SRC / p).read_text()
        chunks.append("<script>\n/* ===== %s ===== */\n%s\n</script>\n" % (p, body))
    chunks.append((SRC / "99_foot.html").read_text())
    html = "".join(chunks)
    OUT.write_text(html)
    kb = len(html) / 1024
    # sanity: no unresolved includes
    assert "<<<" not in html, "unresolved placeholder"
    print(f"built {OUT}  ({kb:.1f} KB, {html.count(chr(10))} lines)")

if __name__ == "__main__":
    main()
