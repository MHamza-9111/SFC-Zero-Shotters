/* DineIQ Analytics — Restaurant Intelligence Dashboard Script */

document.addEventListener("DOMContentLoaded", () => {
    initTheme();
    initScrollProgress();
    initTabs();
    initCountUp();
    initTilt();
    initChartReveal();
    loadStatus();
    setupPredictor();
    renderLeaderboard();
    renderCategoryDonut();
    renderPeakHours();
});

/* ---------------- THEME ---------------- */
function initTheme() {
    const root = document.documentElement;
    const toggle = document.getElementById("themeToggle");
    let saved = null;
    try { saved = localStorage.getItem("dineiq-theme"); } catch (e) {}
    if (saved) root.setAttribute("data-theme", saved);

    toggle.addEventListener("click", () => {
        const current = root.getAttribute("data-theme") ||
            (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
        const next = current === "dark" ? "light" : "dark";
        root.setAttribute("data-theme", next);
        try { localStorage.setItem("dineiq-theme", next); } catch (e) {}
    });
}

/* ---------------- SCROLL PROGRESS ---------------- */
function initScrollProgress() {
    const bar = document.getElementById("scrollProgress");
    function onScroll() {
        const h = document.documentElement;
        const scrolled = (h.scrollTop) / (h.scrollHeight - h.clientHeight) * 100;
        bar.style.width = scrolled + "%";
    }
    document.addEventListener("scroll", onScroll, { passive: true });
}

/* ---------------- TABS ---------------- */
function initTabs() {
    const tabBtns = document.querySelectorAll(".tab-btn");
    const tabContents = document.querySelectorAll(".tab-content");

    tabBtns.forEach(btn => {
        btn.addEventListener("click", () => {
            const target = btn.dataset.tab;
            tabBtns.forEach(b => b.classList.remove("active"));
            tabContents.forEach(c => c.classList.remove("active"));
            btn.classList.add("active");
            document.getElementById(target).classList.add("active");
            // re-trigger chart reveal for newly shown cards
            requestAnimationFrame(() => {
                document.querySelectorAll(`#${target} .chart-card`).forEach(el => el.classList.add("in"));
            });
        });
    });
}

/* ---------------- COUNT-UP KPI NUMBERS ---------------- */
function initCountUp() {
    const els = document.querySelectorAll(".stat-value[data-count]");
    const io = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateCount(entry.target);
                io.unobserve(entry.target);
            }
        });
    }, { threshold: 0.4 });
    els.forEach(el => io.observe(el));
}

function animateCount(el) {
    const target = parseFloat(el.dataset.count);
    const decimals = parseInt(el.dataset.decimals || "0", 10);
    const suffix = el.dataset.suffix || "";
    const duration = 1300;
    let start = null;

    function frame(ts) {
        if (!start) start = ts;
        const progress = Math.min((ts - start) / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        const val = target * eased;
        const formatted = decimals > 0 ? val.toFixed(decimals) : Math.round(val).toLocaleString();
        el.textContent = formatted + suffix;
        if (progress < 1) requestAnimationFrame(frame);
        else el.textContent = (decimals > 0 ? target.toFixed(decimals) : target.toLocaleString()) + suffix;
    }
    requestAnimationFrame(frame);
}

/* ---------------- 3D TILT ---------------- */
function initTilt() {
    const cards = document.querySelectorAll("[data-tilt]");
    cards.forEach(card => {
        card.addEventListener("mousemove", (e) => {
            const b = card.getBoundingClientRect();
            const x = (e.clientX - b.left) / b.width;
            const y = (e.clientY - b.top) / b.height;
            const rx = (0.5 - y) * 9;
            const ry = (x - 0.5) * 9;
            card.style.transform = `perspective(800px) rotateX(${rx}deg) rotateY(${ry}deg) translateY(-3px)`;
            card.style.setProperty("--mx", (x * 100) + "%");
            card.style.setProperty("--my", (y * 100) + "%");
        });
        card.addEventListener("mouseleave", () => {
            card.style.transform = "perspective(800px) rotateX(0) rotateY(0) translateY(0)";
        });
    });
}

/* ---------------- CHART CARD SCROLL REVEAL ---------------- */
function initChartReveal() {
    const cards = document.querySelectorAll(".chart-card");
    const io = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add("in");
                io.unobserve(entry.target);
            }
        });
    }, { threshold: 0.15, rootMargin: "0px 0px -60px 0px" });
    cards.forEach(el => io.observe(el));
}

/* ---------------- STATUS ---------------- */
async function loadStatus() {
    try {
        const res = await fetch("/api/v1/status");
        if (res.ok) {
            const data = await res.json();
            document.getElementById("api-status").textContent = data.status;
        }
    } catch (e) {
        console.warn("API status fetch error:", e);
    }
}

/* ---------------- PREDICTOR ---------------- */
function setupPredictor() {
    const btn = document.getElementById("predict-btn");
    const resultBox = document.getElementById("result-box");
    if (!btn) return;

    btn.addEventListener("click", async () => {
        const originalText = btn.textContent;
        btn.textContent = "Scoring Ensemble Models...";
        btn.disabled = true;
        resultBox.classList.remove("show");

        const record = {
            total_amount: parseFloat(document.getElementById("input-amount").value) || 2500,
            item_count: parseInt(document.getElementById("input-items").value) || 4,
            past_orders: parseInt(document.getElementById("input-orders").value) || 10,
            total_spend: parseFloat(document.getElementById("input-spend").value) || 15000,
            promo_applied: parseInt(document.getElementById("input-promo").value) || 0
        };

        try {
            const res = await fetch("/api/v1/predict/ensemble", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ task: "high_value_order", records: [record] })
            });
            const data = await res.json();
            renderResult(data, record);
        } catch (e) {
            resultBox.innerHTML = `<p style="color:var(--chili);">Could not reach the scoring endpoint. Run <code>python src/backend/app.py</code> and try again.</p>`;
            resultBox.classList.add("show");
        } finally {
            btn.textContent = originalText;
            btn.disabled = false;
        }
    });
}

function renderResult(data, record) {
    const resultBox = document.getElementById("result-box");
    let sparkPred = "—", pyPred = "—", ensemble = "—", agree = "—";
    try {
        const r = Array.isArray(data.results) ? data.results[0] : (data.result || data);
        sparkPred = r.pipeline_prediction ?? r.spark_prediction ?? r.pipeline_score ?? "n/a";
        pyPred = r.python_prediction ?? r.python_score ?? "n/a";
        ensemble = r.ensemble_prediction ?? r.ensemble_score ?? r.prediction ?? "n/a";
        agree = (r.agreement === true || r.agree === true) ? "Match" : (r.agreement === false ? "No match" : "—");
    } catch (e) { /* fall through to raw display */ }

    resultBox.innerHTML = `
        <div class="result-grid">
            <div class="result-item">
                <div class="r-label">Spark MLlib</div>
                <div class="r-value">${sparkPred}</div>
            </div>
            <div class="result-item">
                <div class="r-label">Scikit-Learn Python</div>
                <div class="r-value">${pyPred}</div>
            </div>
            <div class="result-item">
                <div class="r-label">Pipeline Agreement</div>
                <div class="r-value ${agree === 'Match' ? 'match' : ''}">${agree}</div>
            </div>
        </div>
        <p style="margin-top:16px; font-size:12.5px; color:var(--ink-faint);">Order PKR ${record.total_amount.toLocaleString()} · ${record.item_count} items · customer history ${record.past_orders} orders / PKR ${record.total_spend.toLocaleString()} spend</p>
    `;
    resultBox.classList.add("show");
}

/* ---------------- REAL DATA: LOCATION LEADERBOARD ---------------- */
function renderLeaderboard() {
    const el = document.getElementById("leaderboard");
    if (!el) return;
    // Top locations from reports/spark_execution/location_ranking.csv
    const data = [
        { name: "South-12",   revenue: 86077442 },
        { name: "South-2",    revenue: 71036319 },
        { name: "Central-15", revenue: 70327465 },
        { name: "Central-5",  revenue: 65856587 },
        { name: "Garden-6",   revenue: 61359638 }
    ];
    const max = Math.max(...data.map(d => d.revenue));
    el.innerHTML = data.map((d, i) => `
        <div class="lb-row">
            <div class="lb-rank">0${i + 1}</div>
            <div class="lb-name">${d.name}</div>
            <div class="lb-bar-wrap"><div class="lb-bar" data-width="${(d.revenue / max * 100).toFixed(1)}"></div></div>
            <div class="lb-rev">PKR ${(d.revenue / 1e6).toFixed(1)}M</div>
        </div>
    `).join("");

    const io = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.querySelectorAll(".lb-bar").forEach(bar => {
                    bar.style.width = bar.dataset.width + "%";
                });
                io.unobserve(entry.target);
            }
        });
    }, { threshold: 0.3 });
    io.observe(el);
}

/* ---------------- REAL DATA: CATEGORY DONUT ---------------- */
function renderCategoryDonut() {
    const svg = document.getElementById("donutChart");
    const legend = document.getElementById("catLegend");
    if (!svg || !legend) return;

    // From reports/spark_execution/category_revenue_share.csv
    const cats = [
        { name: "Pizza",      share: 0.1774, color: "var(--chili)" },
        { name: "BBQ",        share: 0.1537, color: "var(--gold)" },
        { name: "Pasta",      share: 0.1292, color: "var(--basil)" },
        { name: "Sandwiches", share: 0.1075, color: "#8B6F4E" },
        { name: "Burgers",    share: 0.1059, color: "#C97B5A" },
        { name: "Biryani",    share: 0.0923, color: "#D9A441" },
        { name: "Rice",       share: 0.0719, color: "#6E8C5A" },
        { name: "Desserts",   share: 0.0679, color: "#B65C8C" },
        { name: "Salads",     share: 0.0563, color: "#5B8A72" },
        { name: "Beverages",  share: 0.0378, color: "#7A93B0" }
    ];

    const cx = 100, cy = 100, r = 78, strokeW = 26;
    const circumference = 2 * Math.PI * r;
    let offset = 0;
    const ns = "http://www.w3.org/2000/svg";

    cats.forEach((c) => {
        const dash = c.share * circumference;
        const circle = document.createElementNS(ns, "circle");
        circle.setAttribute("cx", cx);
        circle.setAttribute("cy", cy);
        circle.setAttribute("r", r);
        circle.setAttribute("fill", "none");
        circle.setAttribute("stroke", c.color);
        circle.setAttribute("stroke-width", strokeW);
        circle.setAttribute("stroke-dasharray", `0 ${circumference}`);
        circle.setAttribute("stroke-dashoffset", -offset);
        circle.setAttribute("transform", `rotate(-90 ${cx} ${cy})`);
        circle.style.transition = "stroke-dasharray 1.1s cubic-bezier(.16,1,.3,1)";
        circle.dataset.dash = dash.toFixed(2);
        svg.appendChild(circle);
        offset += dash;
    });

    legend.innerHTML = cats.map(c => `
        <div class="cat-row">
            <span class="cat-swatch" style="background:${c.color}"></span>
            <span class="cat-name">${c.name}</span>
            <span class="cat-pct">${(c.share * 100).toFixed(1)}%</span>
        </div>
    `).join("");

    const io = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                svg.querySelectorAll("circle").forEach(circle => {
                    circle.setAttribute("stroke-dasharray", `${circle.dataset.dash} ${circumference}`);
                });
                io.unobserve(entry.target);
            }
        });
    }, { threshold: 0.3 });
    io.observe(svg);
}

/* ---------------- REAL DATA: PEAK HOURS ---------------- */
function renderPeakHours() {
    const svg = document.getElementById("peakChart");
    if (!svg) return;

    // From reports/spark_execution/peak_hours.csv
    const hours = [9,10,11,12,13,14,15,16,17,18,19,20,21,22];
    const weekday = [869,878,881,5196,5160,5269,1734,1736,1657,5945,5903,5899,8584,2611];
    const weekend = [440,448,499,2742,2744,2712,908,939,884,3160,3099,3167,4526,1340];

    const W = 720, H = 220, padL = 34, padB = 26, padT = 10, padR = 10;
    const chartW = W - padL - padR, chartH = H - padT - padB;
    const maxVal = Math.max(...weekday, ...weekend);
    const ns = "http://www.w3.org/2000/svg";

    function pathFor(arr) {
        return arr.map((v, i) => {
            const x = padL + (i / (arr.length - 1)) * chartW;
            const y = padT + chartH - (v / maxVal) * chartH;
            return `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
        }).join(" ");
    }

    // gridlines
    for (let g = 0; g <= 3; g++) {
        const y = padT + (g / 3) * chartH;
        const line = document.createElementNS(ns, "line");
        line.setAttribute("x1", padL); line.setAttribute("x2", W - padR);
        line.setAttribute("y1", y); line.setAttribute("y2", y);
        line.setAttribute("stroke", "var(--line)"); line.setAttribute("stroke-width", "1");
        svg.appendChild(line);
    }

    // weekend area+line (basil)
    const weekendPath = pathFor(weekend);
    const weekendArea = document.createElementNS(ns, "path");
    weekendArea.setAttribute("d", `${weekendPath} L${padL + chartW},${padT + chartH} L${padL},${padT + chartH} Z`);
    weekendArea.setAttribute("fill", "var(--basil-glow)");
    svg.appendChild(weekendArea);
    const weekendLine = document.createElementNS(ns, "path");
    weekendLine.setAttribute("d", weekendPath);
    weekendLine.setAttribute("fill", "none");
    weekendLine.setAttribute("stroke", "var(--basil)");
    weekendLine.setAttribute("stroke-width", "2.5");
    weekendLine.setAttribute("stroke-linecap", "round");
    weekendLine.setAttribute("stroke-linejoin", "round");
    svg.appendChild(weekendLine);

    // weekday area+line (chili) — drawn on top, the headline series
    const weekdayPath = pathFor(weekday);
    const weekdayArea = document.createElementNS(ns, "path");
    weekdayArea.setAttribute("d", `${weekdayPath} L${padL + chartW},${padT + chartH} L${padL},${padT + chartH} Z`);
    weekdayArea.setAttribute("fill", "var(--chili-glow)");
    svg.appendChild(weekdayArea);
    const weekdayLine = document.createElementNS(ns, "path");
    weekdayLine.setAttribute("d", weekdayPath);
    weekdayLine.setAttribute("fill", "none");
    weekdayLine.setAttribute("stroke", "var(--chili)");
    weekdayLine.setAttribute("stroke-width", "3");
    weekdayLine.setAttribute("stroke-linecap", "round");
    weekdayLine.setAttribute("stroke-linejoin", "round");
    svg.appendChild(weekdayLine);

    // peak marker at 21:00 weekday (8584 orders — dinner rush)
    const peakIdx = weekday.indexOf(Math.max(...weekday));
    const px = padL + (peakIdx / (hours.length - 1)) * chartW;
    const py = padT + chartH - (weekday[peakIdx] / maxVal) * chartH;
    const dot = document.createElementNS(ns, "circle");
    dot.setAttribute("cx", px); dot.setAttribute("cy", py); dot.setAttribute("r", 5);
    dot.setAttribute("fill", "var(--chili)"); dot.setAttribute("stroke", "var(--surface)"); dot.setAttribute("stroke-width", "3");
    svg.appendChild(dot);
    const label = document.createElementNS(ns, "text");
    label.setAttribute("x", px); label.setAttribute("y", py - 12);
    label.setAttribute("text-anchor", "middle"); label.setAttribute("font-size", "11");
    label.setAttribute("font-family", "Space Grotesk, sans-serif"); label.setAttribute("font-weight", "600");
    label.setAttribute("fill", "var(--ink)");
    label.textContent = "9 PM dinner rush · 8,584 orders";
    svg.appendChild(label);

    // hour axis labels (every other hour)
    hours.forEach((h, i) => {
        if (i % 2 !== 0) return;
        const x = padL + (i / (hours.length - 1)) * chartW;
        const text = document.createElementNS(ns, "text");
        text.setAttribute("x", x); text.setAttribute("y", H - 6);
        text.setAttribute("text-anchor", "middle"); text.setAttribute("font-size", "10.5");
        text.setAttribute("font-family", "Inter, sans-serif"); text.setAttribute("fill", "var(--ink-faint)");
        text.textContent = h > 12 ? (h - 12) + "p" : h + "a";
        svg.appendChild(text);
    });
}
